import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'core/services/supabase_service.dart';
import 'data/repositories/report_repository.dart';
import 'data/repositories/supervisor_repository.dart';
import 'logic/blocs/reports/report_bloc.dart';
import 'logic/blocs/reports/report_event.dart';
import 'logic/blocs/dashboard/dashboard_bloc.dart';
import 'logic/blocs/dashboard/dashboard_event.dart';
import 'presentation/screens/dashboard_screen.dart';
import 'core/routes/app_router.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url: 'https://cftjaukrygtzguqcafon.supabase.co',
    anonKey:
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNmdGphdWtyeWd0emd1cWNhZm9uIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDgzMjU1NzYsImV4cCI6MjA2MzkwMTU3Nn0.28pIhi_qCDK3SIjCiJa0VuieFx0byoMK-wdmhb4G75c',
  );
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final supabase = Supabase.instance.client;
    final reportRepo = ReportRepository(supabase);
    final supervisorRepo = SupervisorRepository(supabase);

    return MultiRepositoryProvider(
      providers: [
        RepositoryProvider<ReportRepository>.value(value: reportRepo),
        RepositoryProvider<SupervisorRepository>.value(value: supervisorRepo),
      ],
      child: MultiBlocProvider(
        providers: [
          BlocProvider<ReportBloc>(
            create: (_) => ReportBloc(reportRepo)..add(const FetchReports()),
          ),
          BlocProvider<DashboardBloc>(
            create: (_) => DashboardBloc(
              reportRepository: reportRepo,
              supervisorRepository: supervisorRepo,
            )..add(LoadDashboardData()),
          ),
        ],
        child: MaterialApp.router(
          routerConfig: appRouter,
          title: 'Flutter Supabase Dashboard',
          theme: ThemeData(
            primarySwatch: Colors.indigo,
            scaffoldBackgroundColor: Colors.grey[50],
          ),
        ),
      ),
    );
  }
}
