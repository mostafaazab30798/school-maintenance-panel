import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class SupervisorCard extends StatelessWidget {
  final String name;
  final int routineCount;
  final int emergencyCount;
  final int overdueCount;
  final int lateCompletedCount;
  final int maintenanceCount;
  final String supervisorId;

  const SupervisorCard({
    super.key,
    required this.name,
    required this.routineCount,
    required this.emergencyCount,
    required this.overdueCount,
    required this.lateCompletedCount,
    required this.maintenanceCount,
    required this.supervisorId,
  });

  Widget _buildChip(String label, int count, Color color, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      child: Chip(
        backgroundColor: color.withOpacity(0.1),
        avatar: CircleAvatar(
          backgroundColor: color.withOpacity(0.2),
          child: Text('$count', style: TextStyle(color: color, fontSize: 12)),
        ),
        label: Text(label, style: TextStyle(color: color, fontSize: 13)),
        labelPadding: const EdgeInsets.symmetric(horizontal: 8),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.grey.shade300),
        boxShadow: [
          BoxShadow(
            color: Colors.black12.withOpacity(0.04),
            blurRadius: 5,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(name,
              style: Theme.of(context)
                  .textTheme
                  .titleMedium
                  ?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 14),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                _buildChip('Routine', routineCount, Colors.blue, () {}),
                const SizedBox(width: 8),
                _buildChip('Emergency', emergencyCount, Colors.red, () {}),
                const SizedBox(width: 8),
                _buildChip('Overdue', overdueCount, Colors.orange, () {}),
                const SizedBox(width: 8),
                _buildChip(
                    'Late Done', lateCompletedCount, Colors.purple, () {}),
                const SizedBox(width: 8),
                _buildChip('Maintenance', maintenanceCount, Colors.teal, () {
                  context.go('/maintenance-list/$supervisorId');
                }),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              ElevatedButton.icon(
                onPressed: () {
                  context.go('/add-reports/$supervisorId');
                },
                icon: const Icon(Icons.add_circle_outline),
                label: const Text('New Report'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue.shade50,
                  foregroundColor: Colors.blue.shade800,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  elevation: 0,
                ),
              ),
              const SizedBox(width: 12),
              ElevatedButton.icon(
                onPressed: () {
                  context.go('/add-maintenance/$supervisorId');
                },
                icon: const Icon(Icons.build_circle_outlined),
                label: const Text('New Maintenance'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green.shade50,
                  foregroundColor: Colors.green.shade800,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  elevation: 0,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
