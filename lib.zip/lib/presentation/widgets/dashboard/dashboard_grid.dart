import 'package:flutter/material.dart';
import 'indicator_card.dart';
import 'supervisor_card.dart';
import 'completion_progress_card.dart';

class DashboardGrid extends StatelessWidget {
  const DashboardGrid({
    super.key,
    required this.totalReports,
    required this.routineReports,
    required this.emergencyReports,
    required this.completedReports,
    required this.overdueReports,
    required this.lateCompletedReports,
    required this.totalSupervisors,
    required this.completionRate,
    required this.supervisorCards,
    required this.onTapTotalReports,
    required this.onTapRoutineReports,
    required this.onTapEmergencyReports,
    required this.onTapCompletedReports,
    required this.onTapOverdueReports,
    required this.onTapLateCompletedReports,
    required this.onTapTotalSupervisors,
  });

  final int totalReports;
  final int routineReports;
  final int emergencyReports;
  final int completedReports;
  final int overdueReports;
  final int lateCompletedReports;
  final int totalSupervisors;
  final double completionRate;
  final List<Widget> supervisorCards;

  final VoidCallback onTapTotalReports;
  final VoidCallback onTapRoutineReports;
  final VoidCallback onTapEmergencyReports;
  final VoidCallback onTapCompletedReports;
  final VoidCallback onTapOverdueReports;
  final VoidCallback onTapLateCompletedReports;
  final VoidCallback onTapTotalSupervisors;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              IndicatorCard(
                label: 'إجمالي البلاغات',
                count: totalReports,
                color: Colors.blue,
                icon: Icons.report,
                onTap: onTapTotalReports,
              ),
              IndicatorCard(
                label: 'البلاغات الروتينية',
                count: routineReports,
                color: Colors.lightBlue,
                icon: Icons.list_alt,
                onTap: onTapRoutineReports,
              ),
              IndicatorCard(
                label: 'البلاغات الطارئة',
                count: emergencyReports,
                color: Colors.red,
                icon: Icons.warning_amber,
                onTap: onTapEmergencyReports,
              ),
              IndicatorCard(
                label: 'البلاغات المكتملة',
                count: completedReports,
                color: Colors.green,
                icon: Icons.check_circle,
                onTap: onTapCompletedReports,
              ),
              IndicatorCard(
                label: 'البلاغات المتأخرة',
                count: overdueReports,
                color: Colors.orange,
                icon: Icons.schedule,
                onTap: onTapOverdueReports,
              ),
              IndicatorCard(
                label: 'البلاغات التي أُنجزت متأخر',
                count: lateCompletedReports,
                color: Colors.purple,
                icon: Icons.timer_off,
                onTap: onTapLateCompletedReports,
              ),
              IndicatorCard(
                label: 'عدد المشرفين',
                count: totalSupervisors,
                color: Colors.teal,
                icon: Icons.people,
                onTap: onTapTotalSupervisors,
              ),
            ],
          ),
          const SizedBox(height: 24),
          CompletionProgressCard(percentage: completionRate),
          const SizedBox(height: 24),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: supervisorCards,
          ),
        ],
      ),
    );
  }
}
