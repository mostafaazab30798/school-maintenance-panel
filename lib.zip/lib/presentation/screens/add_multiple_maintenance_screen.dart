import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;

import '../../logic/blocs/maintenance_reports/maintenance_bloc.dart';
import '../../logic/blocs/maintenance_reports/maintenance_event.dart';
import '../../logic/blocs/maintenance_reports/maintenance_state.dart';

class AddMaintenanceReportScreen extends StatefulWidget {
  final String supervisorId;
  const AddMaintenanceReportScreen({super.key, required this.supervisorId});

  @override
  State<AddMaintenanceReportScreen> createState() =>
      _AddMaintenanceReportScreenState();
}

class _AddMaintenanceReportScreenState
    extends State<AddMaintenanceReportScreen> {
  final _formKey = GlobalKey<FormState>();
  String? schoolName;
  String? notes;
  String? scheduledDate;
  List<String> imageUrls = [];
  final picker = ImagePicker();

  Future<void> pickImages() async {
    final picked = await picker.pickMultiImage();
    if (picked.isEmpty) return;

    for (var file in picked) {
      final bytes = await file.readAsBytes();
      final base64Image = base64Encode(bytes);
      final timestamp = DateTime.now().millisecondsSinceEpoch.toString();
      final publicId = 'image_$timestamp';

      final response = await http.post(
        Uri.parse('https://api.cloudinary.com/v1_1/dg7rsus0g/image/upload'),
        body: {
          'file': 'data:image/jpeg;base64,$base64Image',
          'upload_preset': 'managment_upload',
          'public_id': publicId,
          'folder': 'maintenance_reports'
        },
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final url = data['secure_url'];
        imageUrls.add(url);
      }
    }

    setState(() {});
  }

  void submitMaintenance() {
    if (_formKey.currentState?.validate() ?? false) {
      _formKey.currentState?.save();

      context.read<MaintenanceReportBloc>().add(
            SubmitMaintenanceReport(
              supervisorId: widget.supervisorId,
              schoolName: schoolName!,
              notes: notes!,
              scheduledDate: scheduledDate!,
              imageUrls: imageUrls,
            ),
          );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إضافة صيانة دورية')),
      body: BlocListener<MaintenanceReportBloc, MaintenanceReportState>(
        listener: (context, state) {
          if (state is MaintenanceReportLoading) {
            showDialog(
              context: context,
              barrierDismissible: false,
              builder: (_) => const Center(child: CircularProgressIndicator()),
            );
          } else {
            Navigator.of(context, rootNavigator: true).maybePop();
          }

          if (state is MaintenanceReportSuccess) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('تم إرسال الصيانة بنجاح')),
            );
            Navigator.pop(context);
          } else if (state is MaintenanceReportFailure) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('خطأ: ${state.error}')),
            );
          }
        },
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            key: _formKey,
            child: ListView(
              children: [
                TextFormField(
                  decoration: const InputDecoration(labelText: 'اسم المدرسة'),
                  onSaved: (val) => schoolName = val,
                  validator: (val) =>
                      val == null || val.isEmpty ? 'مطلوب' : null,
                ),
                DropdownButtonFormField<String>(
                  decoration: const InputDecoration(labelText: 'تاريخ الصيانة'),
                  items: const [
                    DropdownMenuItem(value: 'today', child: Text('اليوم')),
                    DropdownMenuItem(value: 'tomorrow', child: Text('غدًا')),
                    DropdownMenuItem(
                        value: 'after_tomorrow', child: Text('بعد الغد')),
                  ],
                  onChanged: (val) => scheduledDate = val,
                  validator: (val) => val == null ? 'مطلوب' : null,
                ),
                TextFormField(
                  decoration: const InputDecoration(labelText: 'ملاحظات'),
                  onSaved: (val) => notes = val,
                  validator: (val) =>
                      val == null || val.isEmpty ? 'مطلوب' : null,
                  maxLines: 3,
                ),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: pickImages,
                  child: const Text('إرفاق صور'),
                ),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: submitMaintenance,
                  child: const Text('رفع الصيانة'),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
