import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../logic/blocs/dashboard/dashboard_bloc.dart';
import '../../logic/blocs/dashboard/dashboard_state.dart';
import '../widgets/dashboard/dashboard_grid.dart';
import '../widgets/dashboard/supervisor_card.dart';
import 'add_multiple_reports_screen.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('لوحة التحكم'),
          centerTitle: true,
        ),
        body: BlocBuilder<DashboardBloc, DashboardState>(
          builder: (context, state) {
            if (state is DashboardLoading) {
              return const Center(child: CircularProgressIndicator());
            } else if (state is DashboardError) {
              return Center(child: Text('حدث خطأ: ${state.message}'));
            } else if (state is DashboardLoaded) {
              final supervisorCards = state.supervisors.map((supervisor) {
                final supervisorReports = state.reports
                    .where((r) => r.supervisorId == supervisor.id)
                    .toList();
                final routine = supervisorReports
                    .where((r) => r.type.toLowerCase() == 'روتيني')
                    .length;
                final emergency = supervisorReports
                    .where((r) => r.type.toLowerCase() == 'طارئ')
                    .length;
                final overdue = supervisorReports
                    .where((r) => r.status.toLowerCase() == 'late')
                    .length;
                final lateDone = supervisorReports
                    .where((r) => r.status.toLowerCase() == 'late_completed')
                    .length;
                final maintenance = 0; // You can link it later

                return SupervisorCard(
                  supervisorId: supervisor.id,
                  name: supervisor.username,
                  routineCount: routine,
                  emergencyCount: emergency,
                  overdueCount: overdue,
                  lateCompletedCount: lateDone,
                  maintenanceCount: maintenance,
                );
              }).toList();

              return DashboardGrid(
                totalReports: state.totalReports,
                routineReports: state.routineReports,
                emergencyReports: state.emergencyReports,
                completedReports: state.completedReports,
                overdueReports: state.overdueReports,
                lateCompletedReports: state.lateCompletedReports,
                totalSupervisors: state.totalSupervisors,
                completionRate: state.completionRate,
                supervisorCards: supervisorCards,
                onTapTotalReports: () => print('عرض كل البلاغات'),
                onTapEmergencyReports: () => print('عرض الطارئة'),
                onTapCompletedReports: () => print('عرض المكتملة'),
                onTapOverdueReports: () => print('عرض المتأخرة'),
                onTapLateCompletedReports: () => print('عرض المتأخرة المنجزة'),
                onTapTotalSupervisors: () => print('عرض المشرفين'),
                onTapRoutineReports: () {},
              );
            }

            return const SizedBox();
          },
        ),
      ),
    );
  }
}
