import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;

import '../../logic/cubits/add_multiple_reports_cubit.dart';
import '../../logic/blocs/multi_reports/multi_reports_bloc.dart';
import '../../logic/blocs/multi_reports/multi_reports_event.dart';
import '../../logic/cubits/add_multiple_reports_state.dart';

class AddMultipleReportsScreen extends StatelessWidget {
  final String supervisorId;
  const AddMultipleReportsScreen({super.key, required this.supervisorId});

  Future<void> pickAndUploadImages(
      BuildContext context, int reportIndex) async {
    final picker = ImagePicker();
    final picked = await picker.pickMultiImage();
    if (picked.isEmpty) return;

    List<String> uploadedUrls = [];

    for (var file in picked) {
      final bytes = await file.readAsBytes();
      final base64Image = base64Encode(bytes);
      final timestamp = DateTime.now().millisecondsSinceEpoch.toString();
      final publicId = 'image_$timestamp';

      final response = await http.post(
        Uri.parse('https://api.cloudinary.com/v1_1/dg7rsus0g/image/upload'),
        body: {
          'file': 'data:image/jpeg;base64,$base64Image',
          'upload_preset': 'managment_upload',
          'public_id': publicId,
          'folder': 'reports'
        },
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final url = data['secure_url'];
        uploadedUrls.add(url);
      }
    }

    context
        .read<AddMultipleReportsCubit>()
        .updateImages(reportIndex, uploadedUrls);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${uploadedUrls.length} صورة تم رفعها')),
    );
  }

  void submitReports(BuildContext context) {
    final cubit = context.read<AddMultipleReportsCubit>();
    cubit.submitReports((reports) {
      print('Reports submitted from UI: $reports');

      final bloc = context.read<MultipleReportBloc>();
      bloc.add(SubmitMultipleReports(reports));
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم إرسال البلاغات')),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إضافة بلاغات متعددة')),
      body: BlocBuilder<AddMultipleReportsCubit, AddMultipleReportsState>(
        builder: (context, state) {
          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: state.reports.length + 1,
            itemBuilder: (context, index) {
              if (index == state.reports.length) {
                return Column(
                  children: [
                    const SizedBox(height: 12),
                    ElevatedButton.icon(
                      onPressed: () => context
                          .read<AddMultipleReportsCubit>()
                          .addReport(supervisorId),
                      icon: const Icon(Icons.add),
                      label: const Text('إضافة بلاغ جديد'),
                    ),
                    const SizedBox(height: 24),
                    ElevatedButton(
                      onPressed: () => submitReports(context),
                      child: state.isSubmitting
                          ? const CircularProgressIndicator()
                          : const Text('رفع البلاغات دفعة واحدة'),
                    ),
                  ],
                );
              }
              return ReportFormCard(index: index);
            },
          );
        },
      ),
    );
  }
}

class ReportFormCard extends StatelessWidget {
  final int index;

  const ReportFormCard({super.key, required this.index});

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<AddMultipleReportsCubit>();
    final data = cubit.state.reports[index];

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextFormField(
              decoration: const InputDecoration(
                labelText: 'اسم المدرسة',
                prefixIcon: Icon(Icons.school),
              ),
              initialValue: data.schoolName,
              onChanged: (val) => cubit.updateSchoolName(index, val),
              validator: (val) =>
                  val == null || val.isEmpty ? 'برجاء إدخال اسم المدرسة' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              decoration: const InputDecoration(
                labelText: 'وصف البلاغ',
                prefixIcon: Icon(Icons.description),
              ),
              initialValue: data.description,
              maxLines: 3,
              onChanged: (val) => cubit.updateDescription(index, val),
              validator: (val) =>
                  val == null || val.isEmpty ? 'برجاء إدخال وصف للبلاغ' : null,
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              decoration: const InputDecoration(
                labelText: 'نوع البلاغ',
                prefixIcon: Icon(Icons.build),
              ),
              value: data.type,
              items: const [
                DropdownMenuItem(value: 'Plumbing', child: Text('سباكة')),
                DropdownMenuItem(value: 'Electricity', child: Text('كهربا')),
                DropdownMenuItem(value: 'AC', child: Text('تكييف')),
                DropdownMenuItem(value: 'Civil', child: Text('مدني')),
                DropdownMenuItem(value: 'Fire', child: Text('حريق')),
              ],
              onChanged: (val) => cubit.updateType(index, val!),
              validator: (val) =>
                  val == null || val.isEmpty ? 'برجاء اختيار نوع البلاغ' : null,
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: data.priority,
              decoration: const InputDecoration(labelText: 'أولوية البلاغ'),
              items: const [
                DropdownMenuItem(value: 'Routine', child: Text('روتيني')),
                DropdownMenuItem(value: 'Emergency', child: Text('طارئ')),
              ],
              onChanged: (val) => context
                  .read<AddMultipleReportsCubit>()
                  .updatePriority(index, val!),
              validator: (val) =>
                  val == null || val.isEmpty ? 'برجاء اختيار الأولوية' : null,
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              decoration: const InputDecoration(
                labelText: 'تاريخ الجدولة',
                prefixIcon: Icon(Icons.date_range),
              ),
              value: data.scheduledDate,
              items: const [
                DropdownMenuItem(value: 'today', child: Text('اليوم')),
                DropdownMenuItem(value: 'tomorrow', child: Text('غدًا')),
                DropdownMenuItem(
                    value: 'after_tomorrow', child: Text('بعد الغد')),
              ],
              onChanged: (val) => cubit.updateSchedule(index, val!),
              validator: (val) => val == null || val.isEmpty
                  ? 'برجاء اختيار تاريخ الجدولة'
                  : null,
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton.icon(
                  onPressed: () => cubit.pickImagesFromUI(index, context),
                  icon: const Icon(Icons.image),
                  label: const Text('إرفاق صور'),
                ),
                IconButton(
                  onPressed: () => cubit.removeReport(index),
                  icon: const Icon(Icons.delete_outline, color: Colors.red),
                )
              ],
            ),
          ],
        ),
      ),
    );
  }
}
