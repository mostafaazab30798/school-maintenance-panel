import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../logic/blocs/reports/report_bloc.dart';
import '../../../logic/blocs/reports/report_event.dart';
import '../../../logic/blocs/reports/report_state.dart';
import '../../../data/models/report.dart';

class ReportScreen extends StatelessWidget {
  const ReportScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('البلاغات')),
      body: BlocBuilder<ReportBloc, ReportState>(
        builder: (context, state) {
          if (state is ReportLoading) {
            return const Center(child: CircularProgressIndicator());
          } else if (state is ReportLoaded) {
            if (state.reports.isEmpty) {
              return const Center(child: Text('لا يوجد بلاغات.'));
            }
            return ListView.builder(
              itemCount: state.reports.length,
              itemBuilder: (context, index) {
                final Report report = state.reports[index];
                return Card(
                  margin:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: ListTile(
                    title: Text(report.schoolName),
                    subtitle: Text('${report.description}\n${report.status}'),
                    trailing: Text(report.priority),
                    onTap: () {
                      // Navigate or show details
                    },
                  ),
                );
              },
            );
          } else if (state is ReportError) {
            return Center(child: Text('خطأ: ${state.message}'));
          } else {
            return const Center(child: Text('تحميل البيانات...'));
          }
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          context.read<ReportBloc>().add(const FetchReports());
        },
        child: const Icon(Icons.refresh),
      ),
    );
  }
}
