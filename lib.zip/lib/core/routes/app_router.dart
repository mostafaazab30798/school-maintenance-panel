import 'package:admin_panel/data/repositories/multi_reports_repository.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../logic/blocs/maintenance_reports/maintenance_bloc.dart';
import '../../logic/blocs/multi_reports/multi_reports_bloc.dart';
import '../../logic/cubits/add_multiple_reports_cubit.dart';
import '../../presentation/screens/add_multiple_maintenance_screen.dart';
import '../../presentation/screens/dashboard_screen.dart';
import '../../presentation/screens/add_multiple_reports_screen.dart';
import '../../presentation/screens/maintenance_list_screen.dart';

final GoRouter appRouter = GoRouter(
  routes: [
    GoRoute(
      path: '/',
      name: 'dashboard',
      builder: (context, state) => const DashboardScreen(),
    ),
    GoRoute(
      path: '/add-reports/:supervisorId',
      name: 'add-reports',
      builder: (context, state) {
        final supervisorId = state.pathParameters['supervisorId'] ?? '';

        return MultiBlocProvider(
          providers: [
            BlocProvider<MultipleReportBloc>(
              create: (context) => MultipleReportBloc(
                MultiReportRepository(client: Supabase.instance.client),
              ),
            ),
            BlocProvider<AddMultipleReportsCubit>(
              create: (_) => AddMultipleReportsCubit(supervisorId),
            ),
          ],
          child: AddMultipleReportsScreen(supervisorId: supervisorId),
        );
      },
    ),
    GoRoute(
      path: '/add-maintenance/:supervisorId',
      name: 'add-maintenance',
      builder: (context, state) {
        final supervisorId = state.pathParameters['supervisorId'] ?? '';
        return BlocProvider(
          create: (_) => MaintenanceReportBloc(Supabase.instance.client),
          child: AddMaintenanceReportScreen(supervisorId: supervisorId),
        );
      },
    ),
    GoRoute(
      path: '/maintenance-list/:supervisorId',
      name: 'maintenance-list',
      builder: (context, state) {
        final supervisorId = state.pathParameters['supervisorId'] ?? '';
        return SupervisorMaintenanceListScreen(supervisorId: supervisorId);
      },
    ),
  ],
);
