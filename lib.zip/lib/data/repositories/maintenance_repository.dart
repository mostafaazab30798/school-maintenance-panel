import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/maintenance_report.dart';

class MaintenanceReportRepository {
  final SupabaseClient _client;

  MaintenanceReportRepository(this._client);

  Future<List<MaintenanceReport>> fetchMaintenanceReports(
      {String? supervisorId}) async {
    final query = _client.from('maintenance_reports').select('*');

    if (supervisorId != null) {
      query.eq('supervisor_id', supervisorId);
    }

    query.order('created_at', ascending: false);

    final response = await query;
    if (response is List) {
      return response.map((map) => MaintenanceReport.fromMap(map)).toList();
    } else {
      throw Exception('Failed to load maintenance reports');
    }
  }

  Future<MaintenanceReport> fetchMaintenanceReportById(String id) async {
    final response = await _client
        .from('maintenance_reports')
        .select('*')
        .eq('id', id)
        .single();

    return MaintenanceReport.fromMap(response);
  }

  Future<void> createMaintenanceReport(MaintenanceReport report) async {
    final data = report.toMap()..remove('id');
    await _client.from('maintenance_reports').insert(data);
  }

  Future<void> updateMaintenanceReport(
      String id, Map<String, dynamic> updates) async {
    await _client.from('maintenance_reports').update(updates).eq('id', id);
  }

  Future<void> deleteMaintenanceReport(String id) async {
    await _client.from('maintenance_reports').delete().eq('id', id);
  }
}
