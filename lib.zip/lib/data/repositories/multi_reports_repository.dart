import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/report_form_data.dart';

class MultiReportRepository {
  final SupabaseClient client;

  MultiReportRepository({required this.client});

  Future<void> submitReports(List<ReportFormData> reports) async {
    final List<Map<String, dynamic>> payload = reports.where((r) {
      return r.schoolName?.isNotEmpty == true &&
          r.description?.isNotEmpty == true &&
          r.type?.isNotEmpty == true &&
          (r.priority == 'Routine' || r.priority == 'Emergency') &&
          r.scheduledDate != null;
    }).map((r) {
      final scheduledDate = _mapScheduleToDate(r.scheduledDate ?? '');

      return {
        'school_name': r.schoolName!,
        'description': r.description!,
        'type': r.type!,
        'priority': r.priority!,
        'images': r.imageUrls,
        'status': 'pending',
        'created_at': DateTime.now().toIso8601String(),
        'supervisor_id': r.supervisorId!,
        'scheduled_date': scheduledDate.toIso8601String(),
        'completion_photos': null,
        'completion_note': null,
        'closed_at': null,
      };
    }).toList();

    if (payload.isEmpty) {
      throw Exception('No valid reports to submit.');
    }

    await client.from('reports').insert(payload);
  }

  DateTime _mapScheduleToDate(String value) {
    final today = DateTime.now();
    switch (value) {
      case 'today':
        return today;
      case 'tomorrow':
        return today.add(const Duration(days: 1));
      case 'after_tomorrow':
        return today.add(const Duration(days: 2));
      default:
        return today;
    }
  }
}
