import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/supervisor.dart';

class SupervisorRepository {
  final SupabaseClient _client;

  SupervisorRepository(this._client);

  Future<List<Supervisor>> fetchSupervisors() async {
    final response = await _client
        .from('supervisors')
        .select('*')
        .order('created_at', ascending: false);

    if (response is List) {
      return response.map((map) => Supervisor.fromMap(map)).toList();
    } else {
      throw Exception('Failed to load supervisors');
    }
  }

  Future<Supervisor> fetchSupervisorById(String id) async {
    final response =
        await _client.from('supervisors').select('*').eq('id', id).single();
    return Supervisor.fromMap(response);
  }

  Future<void> createSupervisor(Supervisor supervisor) async {
    final data = supervisor.toMap()..remove('id');
    await _client.from('supervisors').insert(data);
  }

  Future<void> updateSupervisor(String id, Map<String, dynamic> updates) async {
    await _client.from('supervisors').update(updates).eq('id', id);
  }

  Future<void> deleteSupervisor(String id) async {
    await _client.from('supervisors').delete().eq('id', id);
  }
}
