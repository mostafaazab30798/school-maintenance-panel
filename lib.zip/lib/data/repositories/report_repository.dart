import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/report.dart';

class ReportRepository {
  final SupabaseClient _client;

  ReportRepository(this._client);

  Future<List<Report>> fetchReports(
      {String? supervisorId, String? type}) async {
    final query = _client.from('reports').select('*');

    if (supervisorId != null) {
      query.eq('supervisor_id', supervisorId);
    }
    if (type != null) {
      query.eq('type', type);
    }

    query.order('created_at', ascending: false);

    final response = await query;
    if (response is List) {
      return response.map((map) => Report.fromMap(map)).toList();
    } else {
      throw Exception('Failed to load reports');
    }
  }

  Future<Report> fetchReportById(String id) async {
    final response =
        await _client.from('reports').select('*').eq('id', id).single();

    return Report.fromMap(response);
  }

  Future<void> createReport(Report report) async {
    final data = report.toMap()..remove('id'); // Let Supabase handle the ID
    await _client.from('reports').insert(data);
  }

  Future<void> updateReport(String id, Map<String, dynamic> updates) async {
    await _client.from('reports').update(updates).eq('id', id);
  }

  Future<void> deleteReport(String id) async {
    await _client.from('reports').delete().eq('id', id);
  }
}
