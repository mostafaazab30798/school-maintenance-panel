// lib/data/models/report_form_data.dart
class ReportFormData {
  @override
  String toString() {
    return 'ReportFormData(schoolName: $schoolName, description: $description, type: $type, priority: $priority, date: $scheduledDate, images: $imageUrls, supervisorId: $supervisorId)';
  }

  String? schoolName;
  String? description;
  String? type;
  String? priority;
  String? scheduledDate;
  List<String> imageUrls;
  String? supervisorId;

  ReportFormData({
    this.schoolName,
    this.description,
    this.type,
    this.priority,
    this.scheduledDate,
    this.imageUrls = const [],
    this.supervisorId,
  });

  Map<String, dynamic> toMap() {
    return {
      'school_name': schoolName ?? '',
      'description': description ?? '',
      'type': type ?? '',
      'priority': priority ?? '',
      'scheduled_date': scheduledDate,
      'images': imageUrls,
      'status': 'pending',
      'supervisor_id': supervisorId ?? '',
      'created_at': DateTime.now().toIso8601String(),
      'updated_at': DateTime.now().toIso8601String(),
    };
  }
}
