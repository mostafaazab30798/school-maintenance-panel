import 'package:admin_panel/data/models/report_form_data.dart';

class AddMultipleReportsState {
  final List<ReportFormData> reports;
  final bool isSubmitting;

  AddMultipleReportsState({
    required this.reports,
    required this.isSubmitting,
  });

  factory AddMultipleReportsState.initial(String supervisorId) {
    return AddMultipleReportsState(
      reports: [ReportFormData(supervisorId: supervisorId)],
      isSubmitting: false,
    );
  }

  AddMultipleReportsState copyWith({
    List<ReportFormData>? reports,
    bool? isSubmitting,
  }) {
    return AddMultipleReportsState(
      reports: reports ?? this.reports,
      isSubmitting: isSubmitting ?? this.isSubmitting,
    );
  }
}
