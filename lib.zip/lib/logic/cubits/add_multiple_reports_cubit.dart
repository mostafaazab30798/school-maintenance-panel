import 'dart:convert';

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../../data/models/report_form_data.dart';
import 'add_multiple_reports_state.dart';
import 'package:http/http.dart' as http;

class AddMultipleReportsCubit extends Cubit<AddMultipleReportsState> {
  AddMultipleReportsCubit(String supervisorId)
      : super(AddMultipleReportsState.initial(supervisorId));

  void addReport(String supervisorId) {
    final newReports = List<ReportFormData>.from(state.reports)
      ..add(ReportFormData(supervisorId: supervisorId));
    emit(state.copyWith(reports: newReports));
  }

  void removeReport(int index) {
    final updatedReports = List<ReportFormData>.from(state.reports)
      ..removeAt(index);
    emit(state.copyWith(reports: updatedReports));
  }

  void updateSchoolName(int index, String value) {
    final updated = List<ReportFormData>.from(state.reports);
    updated[index].schoolName = value;
    emit(state.copyWith(reports: updated));
  }

  void updateDescription(int index, String value) {
    final updated = List<ReportFormData>.from(state.reports);
    updated[index].description = value;
    emit(state.copyWith(reports: updated));
  }

  void updateType(int index, String value) {
    final updated = List<ReportFormData>.from(state.reports);
    updated[index].type = value;
    emit(state.copyWith(reports: updated));
  }

  void updatePriority(int index, String value) {
    final updated = List<ReportFormData>.from(state.reports);
    updated[index].priority = value;
    emit(state.copyWith(reports: updated));
  }

  void updateSchedule(int index, String value) {
    final updated = List<ReportFormData>.from(state.reports);
    updated[index].scheduledDate = value;
    emit(state.copyWith(reports: updated));
  }

  void updateImages(int index, List<String> urls) {
    final updated = List<ReportFormData>.from(state.reports);
    updated[index].imageUrls = urls;
    emit(state.copyWith(reports: updated));
  }

  void submitReports(void Function(List<ReportFormData>) onSubmit) async {
    emit(state.copyWith(isSubmitting: true));

    try {
      print('Submitting reports: ${state.reports.length}');

      onSubmit(state.reports);
      emit(state.copyWith(isSubmitting: false));
    } catch (e, stack) {
      print('Error submitting reports: $e');
      print(stack);
      emit(state.copyWith(isSubmitting: false));
    }
  }

  Future<void> pickImagesFromUI(int index, BuildContext context) async {
    final picker = ImagePicker();
    final picked = await picker.pickMultiImage();
    if (picked.isEmpty) return;

    List<String> uploadedUrls = [];
    for (var file in picked) {
      final bytes = await file.readAsBytes();
      final base64Image = base64Encode(bytes);
      final timestamp = DateTime.now().millisecondsSinceEpoch.toString();
      final publicId = 'image_$timestamp';

      final response = await http.post(
        Uri.parse('https://api.cloudinary.com/v1_1/dg7rsus0g/image/upload'),
        body: {
          'file': 'data:image/jpeg;base64,$base64Image',
          'upload_preset': 'managment_upload',
          'public_id': publicId,
          'folder': 'reports'
        },
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final url = data['secure_url'];
        uploadedUrls.add(url);
      }
    }

    updateImages(index, uploadedUrls);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${uploadedUrls.length} صورة تم رفعها')),
    );
  }
}
