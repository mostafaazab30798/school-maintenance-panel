import 'package:equatable/equatable.dart';

abstract class ReportEvent extends Equatable {
  const ReportEvent();

  @override
  List<Object?> get props => [];
}

class FetchReports extends ReportEvent {
  final String? supervisorId;
  final String? type;

  const FetchReports({this.supervisorId, this.type});

  @override
  List<Object?> get props => [supervisorId, type];
}
