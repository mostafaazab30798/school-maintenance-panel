import 'package:flutter_bloc/flutter_bloc.dart';
import 'report_event.dart';
import 'report_state.dart';
import '../../../data/repositories/report_repository.dart';

class ReportBloc extends Bloc<ReportEvent, ReportState> {
  final ReportRepository reportRepository;

  ReportBloc(this.reportRepository) : super(ReportInitial()) {
    on<FetchReports>(_onFetchReports);
  }

  Future<void> _onFetchReports(
      FetchReports event, Emitter<ReportState> emit) async {
    emit(ReportLoading());
    try {
      final reports = await reportRepository.fetchReports(
        supervisorId: event.supervisorId,
        type: event.type,
      );
      emit(ReportLoaded(reports));
    } catch (e) {
      emit(ReportError(e.toString()));
    }
  }
}
