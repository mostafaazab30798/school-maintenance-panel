import 'package:flutter_bloc/flutter_bloc.dart';
import 'dashboard_event.dart';
import 'dashboard_state.dart';
import '../../../data/repositories/report_repository.dart';
import '../../../data/repositories/supervisor_repository.dart';

class DashboardBloc extends Bloc<DashboardEvent, DashboardState> {
  final ReportRepository reportRepository;
  final SupervisorRepository supervisorRepository;

  DashboardBloc({
    required this.reportRepository,
    required this.supervisorRepository,
  }) : super(DashboardInitial()) {
    on<LoadDashboardData>(_onLoadDashboardData);
  }

  Future<void> _onLoadDashboardData(
      LoadDashboardData event, Emitter<DashboardState> emit) async {
    try {
      emit(DashboardLoading());

      final reports = await reportRepository.fetchReports();
      final supervisors = await supervisorRepository.fetchSupervisors();

      final totalReports = reports.length;
      final emergencyReports =
          reports.where((r) => r.type.toLowerCase() == 'emergency').length;
      final completedReports =
          reports.where((r) => r.status.toLowerCase() == 'completed').length;
      final overdueReports =
          reports.where((r) => r.status.toLowerCase() == 'late').length;
      final lateCompletedReports = reports
          .where((r) => r.status.toLowerCase() == 'late_completed')
          .length;
      final routineReports = reports.where((r) => r.type == 'regular').length;
      final pendingReports = reports.where((r) => r.status == 'pending').length;
      final totalSupervisors = supervisors.length;

      final completionRate =
          totalReports == 0 ? 0.0 : completedReports / totalReports;

      emit(DashboardLoaded(
        pendingReports: pendingReports,
        routineReports: routineReports,
        totalReports: totalReports,
        emergencyReports: emergencyReports,
        completedReports: completedReports,
        overdueReports: overdueReports,
        lateCompletedReports: lateCompletedReports,
        totalSupervisors: totalSupervisors,
        completionRate: completionRate,
        reports: reports,
        supervisors: supervisors,
      ));
    } catch (e) {
      emit(DashboardError(e.toString()));
    }
  }
}
