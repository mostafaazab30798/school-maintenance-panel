import 'package:admin_panel/logic/blocs/maintenance_reports/maintenance_event.dart';
import 'package:admin_panel/logic/blocs/maintenance_reports/maintenance_state.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class MaintenanceReportBloc
    extends Bloc<MaintenanceReportEvent, MaintenanceReportState> {
  final SupabaseClient client;

  MaintenanceReportBloc(this.client) : super(MaintenanceReportInitial()) {
    on<SubmitMaintenanceReport>(_onSubmit);
  }

  Future<void> _onSubmit(
    SubmitMaintenanceReport event,
    Emitter<MaintenanceReportState> emit,
  ) async {
    emit(MaintenanceReportLoading());

    try {
      final DateTime scheduled = _mapScheduleToDate(event.scheduledDate);

      await client.from('maintenance_reports').insert({
        'supervisor_id': event.supervisorId,
        'school_id': event.schoolName,
        'description': event.notes,
        'status': 'pending',
        'images': event.imageUrls,
        'created_at': DateTime.now().toIso8601String(),
        'scheduled_date': scheduled.toIso8601String(),
      });

      emit(MaintenanceReportSuccess());
    } catch (e) {
      emit(MaintenanceReportFailure(e.toString()));
    }
  }

  DateTime _mapScheduleToDate(String value) {
    final today = DateTime.now();
    switch (value) {
      case 'today':
        return today;
      case 'tomorrow':
        return today.add(const Duration(days: 1));
      case 'after_tomorrow':
        return today.add(const Duration(days: 2));
      default:
        return today;
    }
  }
}
