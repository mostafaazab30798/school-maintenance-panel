import 'package:flutter_bloc/flutter_bloc.dart';
import 'multi_reports_event.dart';
import 'multi_reports_state.dart';
import '../../../data/repositories/multi_reports_repository.dart';

class MultipleReportBloc
    extends Bloc<MultipleReportEvent, MultipleReportState> {
  final MultiReportRepository reportRepository;

  MultipleReportBloc(this.reportRepository) : super(MultipleReportInitial()) {
    on<SubmitMultipleReports>(_onSubmitMultipleReports);
  }

  Future<void> _onSubmitMultipleReports(
    SubmitMultipleReports event,
    Emitter<MultipleReportState> emit,
  ) async {
    emit(MultipleReportsSubmitting());
    try {
      await reportRepository.submitReports(event.reports);
      emit(MultipleReportsSuccess());
    } catch (e) {
      print('Error during report submission: $e');
      emit(MultipleReportsFailure(e.toString()));
    }
  }
}
